import type { components } from '@/api/generated/schema.d.ts';

export type ProblemDetails = components['schemas']['Microsoft.AspNetCore.Http.HttpValidationProblemDetails'];
