<template>
    <PageLayout :breadcrumbs="[{ label: 'Plants Overview' }]">
      <template #actions>
        <q-btn
          class="shadow"
          color="primary"
          text-color="white"
          unelevated
          no-caps
          size="15px"
          :label="'Add Record'"
          :icon="mdiPlus"
          @click="addRecord"
        />
      </template>
      <template #default>
        <q-table
          :rows="plants"
          :columns="columns"
          row-key="id"
          flat
          bordered
          class="bg-white shadow"
        >
          <template v-slot:body-cell-date="props">
            <q-td :props="props">
              {{ formatDate(props.row.date) }}
            </q-td>
          </template>
          <template v-slot:body-cell-progress="props">
            <q-td :props="props">
              <q-linear-progress
                :value="props.row.progress / 100"
                size="16px"
                color="green"
                track-color="grey-3"
                rounded
              >
                {{ props.row.progress }}%
              </q-linear-progress>
            </q-td>
          </template>
        </q-table>
      </template>
    </PageLayout>
  </template>
  
  <script setup lang="ts">
  import { ref } from 'vue';
  import PageLayout from '@/layouts/PageLayout.vue';
  import { mdiPlus } from '@quasar/extras/mdi-v7';
  
  // Breadcrumbs for navigation
  const breadcrumbs = ref([
    { label: 'Home', to: '/' },
    { label: 'Plants', to: '/plants' },
  ]);
  
  // Static data for the table
  const plants = ref([
    { id: "Bonsaj_xx", health: 'Good', leafCount: 12, date: '2024-12-05', progress: 80 },
    { id: "Bonsaj_xx", health: 'Average', leafCount: 8, date: '2024-12-01', progress: 50 },
    { id: "Bonsaj_xx", health: 'Poor', leafCount: 5, date: '2024-11-24', progress: 30 },
  ]);
  
  // Table columns
  const columns = ref([
    { name: 'id', required: true, label: 'Plant ID', align: 'left', field: 'id', sortable: true },
    { name: 'health', required: true, label: 'Health', align: 'left', field: 'health', sortable: true },
    { name: 'leafCount', required: true, label: 'Leaf Count', align: 'right', field: 'leafCount', sortable: true },
    { name: 'date', required: true, label: 'Date', align: 'left', field: 'date', sortable: true },
    { name: 'progress', required: true, label: 'Progress', align: 'left', field: 'progress', sortable: false },
  ]);
  
  // Function to format dates
  function formatDate(date: string): string {
    const parsedDate = new Date(date);
    if (isNaN(parsedDate.getTime())) {
      return 'Invalid date';
    }
    const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
    return parsedDate.toLocaleDateString('en-US', options);
  }
  
  // Function for Add Record button
  function addRecord() {
    alert('Add Record button clicked!');
  }
  </script>
  
  <style scoped>
  .q-btn.flat {
    margin: 0;
    padding: 0.5rem 1rem;
  }
  </style>
  