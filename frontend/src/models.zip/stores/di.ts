import { defineStore } from 'pinia';

//ioc container for router
export const useDiStore = defineStore('di', () => ({}));
