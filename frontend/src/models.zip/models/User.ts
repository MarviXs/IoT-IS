interface User {
  id: string;
  email: string;
}

export type { User };
