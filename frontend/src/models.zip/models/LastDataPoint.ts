interface LastDataPoint {
  deviceId: string;
  tag: string;
  value?: number | null;
}

export type { LastDataPoint };
