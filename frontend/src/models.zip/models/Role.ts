enum Role {
  ADMIN = 'Admin',
  USER = 'User',
}

export { Role };
