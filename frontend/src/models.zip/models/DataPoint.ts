interface DataPoint {
  ts: string;
  value?: number | null;
}

export type { DataPoint };
